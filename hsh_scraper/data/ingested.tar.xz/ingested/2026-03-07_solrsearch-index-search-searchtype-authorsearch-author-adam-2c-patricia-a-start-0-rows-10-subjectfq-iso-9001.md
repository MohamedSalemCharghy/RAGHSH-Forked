---
source_url: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001"
title: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001"
crawl_date: "2026-03-07"
content_type: "html"
---

### Filtern
#### Autor*in 
  * [Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/author_facetfq/Adam%2C+Patricia+A.) (6)
  * [Japing, Tonio](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/author_facetfq/Japing%2C+Tonio) (1)


#### Erscheinungsjahr 
  * [2024](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/yearfq/2024) (2)
  * [2021](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/yearfq/2021) (3)
  * [2018](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/yearfq/2018) (1)


#### Dokumenttyp 
  * [Preprint](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/doctypefq/preprint) (4)
  * [Konferenzveröffentlichung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/doctypefq/conferenceobject) (1)
  * [Arbeitspapier](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/doctypefq/workingpaper) (1)


#### Sprache 
  * [Deutsch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/languagefq/deu) (4)
  * [Englisch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/languagefq/eng) (2)


#### Volltext vorhanden 
  * [ja](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/has_fulltextfq/true) (6)


#### Gehört zur Bibliographie 
  * [nein](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/belongs_to_bibliographyfq/false) (6)


#### Schlagworte 
  * ISO 9001 (6) [(entfernen)](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./rows/10)


#### Institut 
  * [Fakultät IV - Wirtschaft und Informatik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/institutefq/Fakult%C3%A4t+IV+-+Wirtschaft+und+Informatik) (6)


###  6 Treffer
  * **1** bis **6**


Export
  * [BibTeX](https://serwiss.bib.hs-hannover.de/export/index/bibtex/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001 "Export BibTeX")
  * [CSV](https://serwiss.bib.hs-hannover.de/export/index/csv/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001 "Export CSV")
  * [RIS](https://serwiss.bib.hs-hannover.de/export/index/ris/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001 "Export RIS")


10
  * [10](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001)
  * [20](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/20/subjectfq/ISO+9001)
  * [50](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/50/subjectfq/ISO+9001)
  * [100](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/100/subjectfq/ISO+9001)


Sortieren nach
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/sortfield/year/sortorder/asc)
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/sortfield/year/sortorder/desc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/sortfield/title/sortorder/asc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/sortfield/title/sortorder/desc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/sortfield/author/sortorder/asc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/sortfield/author/sortorder/desc)


[System(at)isch agil – Wie agile Prozesse in ein Managementsystem nach ISO 9001:2015 integriert werden können](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001/docId/1268) (2018) 
[Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Viele Unternehmen experimentieren mit Agilität. Gleichzeitig ist die Unsicherheit groß, wieviel Agilität ein QM-System nach ISO 9001 tatsächlich verträgt. Ein gemeinsames Forschungsprojekt der Hochschule Hannover und der DGQ hat sich zum Ziel gesetzt, hier mehr Sicherheit zu geben. Aus Interviews mit Vertretern von Unternehmen, welche teilweise agil arbeiten, entstand erstmals eine klare Definition von Agilität, agilen Praktiken und agilen Prozessen im Organisationskontext. Die daraus entwickelten Leitlinien für die Integration von agilen Vorgehensweisen in QM-Systeme beweisen schlüssig, dass agile Prozesse grundsätzlich nach den ISO 9001-Kriterien zertifizierungsfähig ausgestaltet werden können.
[Erfolgreich mit Integriertem Risiko- und Chancenmanagement - Normkapitel 6.1 gestalten](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/1/rows/10/subjectfq/ISO+9001/docId/3065) (2024) 
[Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Ein Integriertes Risiko- und Chancenmanagement (IRCM) geht deutlich über das hinaus, was in den Organisationen heute anzutreffen ist. Es bietet jedoch die beste Möglichkeit, nicht nur mit der VUKA-Welt Schritt zu halten, sondern sogar von ihr zu profitieren. Entsprechend ist die Einführung eines chancenbasierten Denkens in Ergänzung zum risikobasierten Denken Bestandteil der Revisionsagenda für die ISO 9000 und 9001. Voraussetzung für die erfolgreiche Gestaltung eines IRCM ist die individuelle Definition, Steuerung und Integration von Risiko- und Chancenmanagementprozessen unter Beachtung von 8 Erfolgsfaktoren, den „8K“. Vom Ergebnis profitiert das Top-Management direkt: Bessere, abgestimmte Entscheidungsvorlagen ermöglichen schnellere, sachgerechtere Entscheidungen.
[Integrated Risk and Opportunity Management - Implementing clause 6.1](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/2/rows/10/subjectfq/ISO+9001/docId/3083) (2024) 
[Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Integrated Risk and Opportunity Management (IROM) goes far beyond what is found in organizations today. However, it offers the best opportunity not only to keep pace with the VUCA world, but to actually profit from it. Accordingly, the introduction of opportunity-based thinking in addition to risk-based thinking is part of the design specification for ISO 9000 and ISO 9001. The prerequisite for the successful design of an IROM is the individual definition, control and integration of risk and opportunity management processes, considering eight success factors, the "8 C". Top management benefits directly from the result: better, coordinated decision memos enable faster and more appropriate decisions.
[Practically best friends?! Agility and ISO 9001](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/3/rows/10/subjectfq/ISO+9001/docId/2092) (2021) 
[Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Agility is considered the silver bullet for survival in the VUCA world. However, many organisations are afraid of endangering their ISO 9001 certificate when introducing agile processes. A joint research project of the University of Applied Sciences and Arts Hannover and the DGQ has set itself the goal of providing more security in this area. The findings were based on interviews with managers and team members from various organisations of different sizes and industries working in an agile manner as well as on common audit practices and a literature analysis. The outcome presents a clear distinction of agility from flexibility as well as useful guidelines for the integration of agile processes in QM systems - for QM practitioners and auditors alike.
[Die geplante Flexibilität : ISO 9001-konforme Steuerung agiler Prozesse](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/4/rows/10/subjectfq/ISO+9001/docId/2095) (2021) 
[Japing, Tonio](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio) ; [Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Agile Prozesse und zertifizierte Managementsysteme wirken anfänglich wie ein Widerspruch, insbesondere hinsichtlich der Steuerung des Prozessverlaufs sowie der Kontrolle beabsichtigter Ergebnisse. Doch ein wissenschaftlicher Blick auf etablierte Formen der Prozesssteuerung legte im Rahmen einer Masterarbeit offen, dass sich einheitliche Mechanismen dahinter verbergen, die auch auf agile Prozesse angewendet werden können. Fünf erkannte Prozesssteuerungsmechanismen geben dem Leser konkrete Ansatzpunkte zur ISO 9001-konformen Steuerung und Kontrolle agiler Prozesse.
[Ziemlich beste Freunde - Agilität und ISO 9001](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/5/rows/10/subjectfq/ISO+9001/docId/2094) (2021) 
[Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Viele Unternehmen experimentieren mit Agilität. Gleichzeitig ist die Unsicherheit groß, wieviel Agilität ein QM-System nach ISO 9001 tatsächlich verträgt. Ein gemeinsames Forschungsprojekt der Hochschule Hannover und der DGQ hat sich zum Ziel gesetzt, hier mehr Sicherheit zu geben. Aus Interviews mit Vertretern von Unternehmen, welche teilweise agil arbeiten, entstanden Leitlinien für die Integration von agilen Vorgehensweisen in QM-Systeme und erstmals eine klare Definition von Agilität.
  * **1** bis **6**


