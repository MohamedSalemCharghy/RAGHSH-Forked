---
source_url: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian"
title: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian"
crawl_date: "2026-03-07"
content_type: "html"
---

### Filtern
#### Autor*in 
  * [Bartels, Thomas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Bartels%2C+Thomas) (1)
  * [Beyki, Mohammed](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Beyki%2C+Mohammed) (1)
  * [Flemming, Jesko](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Flemming%2C+Jesko) (1)
  * [Grotjahn, Martin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Grotjahn%2C+Martin) (1)
  * [Grude, Leon](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Grude%2C+Leon) (1)
  * [Heüveldop, Dörte](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/He%C3%BCveldop%2C+D%C3%B6rte) (1)
  * [Homann, Hanno](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Homann%2C+Hanno) (1)
  * [Homeyer, Kai](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Homeyer%2C+Kai) (1)
  * [Jakoblew, Sascha](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Jakoblew%2C+Sascha) (1)
  * [Kallisch, Jonas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/author_facetfq/Kallisch%2C+Jonas) (1)


[ + weitere](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/facetNumber_author_facet/all#author_facet_facet "alle Ergebnisse anzeigen")
#### Erscheinungsjahr 
  * [2024](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/yearfq/2024) (1)


#### Dokumenttyp 
  * [Buch (Monographie)](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/doctypefq/book) (1)


#### Sprache 
  * [Mehrsprachig](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/languagefq/mul) (1)


#### Volltext vorhanden 
  * [ja](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/has_fulltextfq/true) (1)


#### Gehört zur Bibliographie 
  * [nein](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/belongs_to_bibliographyfq/false) (1)


#### Schlagworte 
  * [Automation](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/Automation) (1)
  * [Automation technology](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/Automation+technology) (1)
  * [Datenaustausch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/Datenaustausch) (1)
  * [Geflügelhaltung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/Gefl%C3%BCgelhaltung) (1)
  * [Lichttechnik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/Lichttechnik) (1)
  * [Mössbauer-Spektroskopie](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/M%C3%B6ssbauer-Spektroskopie) (1)
  * [Produktionstechnik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/Produktionstechnik) (1)
  * [Sensor technology](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/Sensor+technology) (1)
  * [Sensortechnik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/subjectfq/Sensortechnik) (1)


#### Institut 
  * [Fakultät I - Elektro- und Informationstechnik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/institutefq/Fakult%C3%A4t+I+-+Elektro-+und+Informationstechnik) (1)
  * [ISA - Institut für Sensorik und Automation](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/start/0/rows/10/institutefq/ISA+-+Institut+f%C3%BCr+Sensorik+und+Automation) (1)


###  1 Treffer
  * **1** bis **1**


Export
  * [BibTeX](https://serwiss.bib.hs-hannover.de/export/index/bibtex/searchtype/authorsearch/author/Tegeler%2C+Sebastian "Export BibTeX")
  * [CSV](https://serwiss.bib.hs-hannover.de/export/index/csv/searchtype/authorsearch/author/Tegeler%2C+Sebastian "Export CSV")
  * [RIS](https://serwiss.bib.hs-hannover.de/export/index/ris/searchtype/authorsearch/author/Tegeler%2C+Sebastian "Export RIS")


10
  * [10](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/rows/10)
  * [20](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/rows/20)
  * [50](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/rows/50)
  * [100](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian/rows/100)


[Sensorik und Automation: Schriften des Forschungsinstituts ISA 2024](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Tegeler%2C+Sebastian/docId/3245/start/0/rows/10) (2024) 
[Bartels, Thomas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Bartels%2C+Thomas) ; [Beyki, Mohammed](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Beyki%2C+Mohammed) ; [Flemming, Jesko](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Flemming%2C+Jesko) ; [Grude, Leon](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Grude%2C+Leon) ; [Homann, Hanno](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Homann%2C+Hanno) ; [Homeyer, Kai](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Homeyer%2C+Kai) ; [Jakoblew, Sascha](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Jakoblew%2C+Sascha) ; [Kallisch, Jonas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Kallisch%2C+Jonas) ; [Kizilarslan, Metin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Kizilarslan%2C+Metin) ; [Knop, Werner](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Knop%2C+Werner) ; [Lachmayer, Roland](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Lachmayer%2C+Roland) ; [Niemann, Karl-Heinz](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Niemann%2C+Karl-Heinz) ; [Passoke, Jens](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Passoke%2C+Jens) ; [Patzke, Robert](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Patzke%2C+Robert) ; [Pawlak, Justus](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Pawlak%2C+Justus) ; [Raabe, Jessica](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica) ; [Raveendran, Gurubaran](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raveendran%2C+Gurubaran) ; [Renz, Franz](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Renz%2C+Franz) ; [Schomburg, Helen](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Schomburg%2C+Helen) ; [Sahan, Benjamin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Sahan%2C+Benjamin) ; [Streitenberger, Martin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Streitenberger%2C+Martin) ; [Tegeler, Sebastian](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian) ; [Will, Jens Christian](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Will%2C+Jens+Christian) ; [Winnefeld, Jannis](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Winnefeld%2C+Jannis) ; [Witte, Pascal](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Witte%2C+Pascal) ; [Wittig, Christoph](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wittig%2C+Christoph) ; [Wicht, Bernhard](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wicht%2C+Bernhard) ; [Wulfmeier, Kirsten](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wulfmeier%2C+Kirsten) ; [Wunck, Christoph](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wunck%2C+Christoph) ; [Heüveldop, Dörte](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/He%C3%BCveldop%2C+D%C3%B6rte) ; [Grotjahn, Martin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Grotjahn%2C+Martin)
Das Institut für Sensorik und Automation (ISA) stellt in acht Beiträgen aktuelle Ergebnisse aus seinen vielfältigen Forschungsprojekten vor. Es werden Themen angesprochen wie Lichttechnik in der Nutzgeflügelhaltung, Datenaustausch in der Produktion, hochfrequente Front-Ends für Umweltsensoren in der Gebäudeautomatisierung, Mössbauer-Spektroskopie, Entwicklung fortschrittlicher Transimpedanzverstärker, Optimierung monostatischer Transceiver, Datenverarbeitungsszenarien für Smart-Home-Systeme und Designüberlegungen für kryogene Analog-Digital-Wandler.
  * **1** bis **1**


