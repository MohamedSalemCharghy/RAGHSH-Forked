---
source_url: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1"
title: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1"
crawl_date: "2026-03-07"
content_type: "html"
---

### Filtern
#### Autor*in 
  * [Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/author_facetfq/Adam%2C+Patricia+A.) (2)


#### Erscheinungsjahr 
  * [2024](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/yearfq/2024) (2)


#### Dokumenttyp 
  * [Preprint](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/doctypefq/preprint) (2)


#### Sprache 
  * [Deutsch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/languagefq/deu) (1)
  * [Englisch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/languagefq/eng) (1)


#### Volltext vorhanden 
  * [ja](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/has_fulltextfq/true) (2)


#### Gehört zur Bibliographie 
  * [nein](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/belongs_to_bibliographyfq/false) (2)


#### Schlagworte 
  * ISO 9001 6.1 (2) [(entfernen)](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./rows/10)


#### Institut 
  * [Fakultät IV - Wirtschaft und Informatik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/institutefq/Fakult%C3%A4t+IV+-+Wirtschaft+und+Informatik) (2)


###  2 Treffer
  * **1** bis **2**


Export
  * [BibTeX](https://serwiss.bib.hs-hannover.de/export/index/bibtex/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1 "Export BibTeX")
  * [CSV](https://serwiss.bib.hs-hannover.de/export/index/csv/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1 "Export CSV")
  * [RIS](https://serwiss.bib.hs-hannover.de/export/index/ris/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1 "Export RIS")


10
  * [10](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1)
  * [20](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/20/subjectfq/ISO+9001+6.1)
  * [50](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/50/subjectfq/ISO+9001+6.1)
  * [100](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/100/subjectfq/ISO+9001+6.1)


Sortieren nach
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/sortfield/year/sortorder/asc)
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/sortfield/year/sortorder/desc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/sortfield/title/sortorder/asc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/sortfield/title/sortorder/desc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/sortfield/author/sortorder/asc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/sortfield/author/sortorder/desc)


[Erfolgreich mit Integriertem Risiko- und Chancenmanagement - Normkapitel 6.1 gestalten](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/0/rows/10/subjectfq/ISO+9001+6.1/docId/3065) (2024) 
[Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Ein Integriertes Risiko- und Chancenmanagement (IRCM) geht deutlich über das hinaus, was in den Organisationen heute anzutreffen ist. Es bietet jedoch die beste Möglichkeit, nicht nur mit der VUKA-Welt Schritt zu halten, sondern sogar von ihr zu profitieren. Entsprechend ist die Einführung eines chancenbasierten Denkens in Ergänzung zum risikobasierten Denken Bestandteil der Revisionsagenda für die ISO 9000 und 9001. Voraussetzung für die erfolgreiche Gestaltung eines IRCM ist die individuelle Definition, Steuerung und Integration von Risiko- und Chancenmanagementprozessen unter Beachtung von 8 Erfolgsfaktoren, den „8K“. Vom Ergebnis profitiert das Top-Management direkt: Bessere, abgestimmte Entscheidungsvorlagen ermöglichen schnellere, sachgerechtere Entscheidungen.
[Integrated Risk and Opportunity Management - Implementing clause 6.1](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Adam%2C+Patricia+A./start/1/rows/10/subjectfq/ISO+9001+6.1/docId/3083) (2024) 
[Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Integrated Risk and Opportunity Management (IROM) goes far beyond what is found in organizations today. However, it offers the best opportunity not only to keep pace with the VUCA world, but to actually profit from it. Accordingly, the introduction of opportunity-based thinking in addition to risk-based thinking is part of the design specification for ISO 9000 and ISO 9001. The prerequisite for the successful design of an IROM is the individual definition, control and integration of risk and opportunity management processes, considering eight success factors, the "8 C". Top management benefits directly from the result: better, coordinated decision memos enable faster and more appropriate decisions.
  * **1** bis **2**


