---
source_url: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek"
title: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek"
crawl_date: "2026-03-07"
content_type: "html"
---

### Filtern
#### Autor*in 
  * [Wittich, Anke](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Wittich%2C+Anke) (3)
  * [Kugler, Simon](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Kugler%2C+Simon) (2)
  * [Bertram, Jutta](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Bertram%2C+Jutta) (1)
  * [Brinster, Denis](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Brinster%2C+Denis) (1)
  * [Bubke, Karolin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Bubke%2C+Karolin) (1)
  * [Bulmahn, Marc](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Bulmahn%2C+Marc) (1)
  * [Groß, Linda](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Gro%C3%9F%2C+Linda) (1)
  * [Helberg, Hjördis](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Helberg%2C+Hj%C3%B6rdis) (1)
  * [Petschenka, Anke](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Petschenka%2C+Anke) (1)
  * [Pläp, Anna](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/author_facetfq/Pl%C3%A4p%2C+Anna) (1)


[ + weitere](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/facetNumber_author_facet/all#author_facet_facet "alle Ergebnisse anzeigen")
#### Erscheinungsjahr 
  * [2024](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/yearfq/2024) (1)
  * [2023](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/yearfq/2023) (2)
  * [2022](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/yearfq/2022) (2)
  * [2014](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/yearfq/2014) (1)


#### Dokumenttyp 
  * [Bachelorarbeit](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/doctypefq/bachelorthesis) (3)
  * [Aufsatz, Zeitschriftenartikel](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/doctypefq/article) (1)
  * [Teil eines Buches (Kapitel)](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/doctypefq/bookpart) (1)
  * [Studienarbeit](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/doctypefq/studythesis) (1)


#### Sprache 
  * [Deutsch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/languagefq/deu) (6)


#### Volltext vorhanden 
  * [ja](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/has_fulltextfq/true) (6)


#### Gehört zur Bibliographie 
  * [nein](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/belongs_to_bibliographyfq/false) (6)


#### Schlagworte 
  * Bibliothek (6) [(entfernen)](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/rows/10)


#### Institut 
  * [Fakultät III - Medien, Information und Design](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/institutefq/Fakult%C3%A4t+III+-+Medien%2C+Information+und+Design) (6)


###  6 Treffer
  * **1** bis **6**


Export
  * [BibTeX](https://serwiss.bib.hs-hannover.de/export/index/bibtex/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek "Export BibTeX")
  * [CSV](https://serwiss.bib.hs-hannover.de/export/index/csv/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek "Export CSV")
  * [RIS](https://serwiss.bib.hs-hannover.de/export/index/ris/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek "Export RIS")


10
  * [10](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek)
  * [20](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/20/subjectfq/Bibliothek)
  * [50](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/50/subjectfq/Bibliothek)
  * [100](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/100/subjectfq/Bibliothek)


Sortieren nach
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/sortfield/year/sortorder/asc)
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/sortfield/year/sortorder/desc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/sortfield/title/sortorder/asc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/sortfield/title/sortorder/desc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/sortfield/author/sortorder/asc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/sortfield/author/sortorder/desc)


[Pop-Up-Bibliotheken. Eine Machbarkeitsstudie](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/persons/Anke+Wittich/start/0/rows/10/subjectfq/Bibliothek/docId/2364) (2022) 
[Brinster, Denis](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Brinster%2C+Denis) ; [Groß, Linda](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Gro%C3%9F%2C+Linda) ; [Helberg, Hjördis](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Helberg%2C+Hj%C3%B6rdis) ; [Kugler, Simon](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Kugler%2C+Simon) ; [Pläp, Anna](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Pl%C3%A4p%2C+Anna) ; [Reuter, Johannes](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Reuter%2C+Johannes) ; [Sarchiello, Sara](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Sarchiello%2C+Sara) ; [Schneider, Patrick](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Schneider%2C+Patrick) ; [Wallmann, Anne-Kathrin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wallmann%2C+Anne-Kathrin) ; [Wolff, Jonas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wolff%2C+Jonas) ; [Bubke, Karolin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Bubke%2C+Karolin) ; [Wittich, Anke](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wittich%2C+Anke)
Pop-Up-Stores dienen diversen Unternehmen, von großen Konzernen bis hin zum kleinen Start-Up-Projekt, als einzigartige Möglichkeit, neuartige Produkte für potenzielle Kunden sichtbar zu machen, deren Attraktivität zu testen und unkonventionelles Marketing zu betreiben. Auch in Deutschland sind die Läden auf Zeit mittlerweile ein etabliertes Konzept. Insbesondere in Großstädten sind sie prägende Elemente von Einkaufszentren, Fußgängerzonen, etc., die durch ihr kurzzeitiges Erscheinen und ihre einzigartigen Angebote auch eine Antwort auf die dynamische Entwicklung von Innenstädten und das Innovationsbedürfnis von Konsumenten darstellen. Durch die begrenzte Verfügbarkeit, die damit zumindest suggerierte Exklusivität und den besonderen Eventcharakter erzeugen Pop-Up-Stores ein hohes Maß an Aufmerksamkeit, Mundpropaganda sowie Attraktivität und sind dabei für die durchführenden Unternehmen annähernd risikolos. Ob und wie dieses Konzept auch für Bibliotheken geeignet ist, welche Vorteile Bibliotheken aus einem derartigen Projekt gegebenenfalls ziehen können und was bei der Umsetzung einer Pop-Up-Bibliothek zu beachten ist, ist Inhalt der vorliegenden Machbarkeitsstudie. Im Rahmen der ersten Recherchen wurde bereits ersichtlich, dass die Bandbreite von Pop-Up-Konzepten an sich sehr groß ist. Darüber hinaus zeigte sich auch, dass Bibliotheken auf unterschiedlichste Weise dazu in der Lage sind, diese Konzepte wiederum an die eigenen Bedürfnisse bzw. Gegebenheiten anzupassen: Vom Testen neuer Raum- oder Veranstaltungsangebote bis zum Schaffen temporärer Bibliotheksstandorte in bisher wenig bis nicht erschlossenen Stadtteilen, und nicht zuletzt als imagewirksame Öffentlichkeitsarbeit – die Möglichkeiten der Ausrichtung einer Pop-Up-Bibliothek sind so divers, wie die Bibliotheksarbeit an sich.
[Usability-Studie zur Website der Landesbibliothek Oldenburg](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/persons/Anke+Wittich/start/1/rows/10/subjectfq/Bibliothek/docId/418) (2014) 
[Richter, Julia](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Richter%2C+Julia) ; [van Lengen, Talea](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/van+Lengen%2C+Talea)
Internetpräsenzen von Bibliotheken müssen zunehmend mit kommerziellen oder frei zugänglichen Informationsangeboten konkurrieren. Um sich von diesen Angeboten abzuheben, müssen nicht nur, wie gehabt, qualitativ hochwertige Informationen bereitgestellt werden - der Zugang zu diesen Informationen muss nutzerfreundlich gestaltet werden und sich an Usability-Standards orientieren, um für den Nutzer attraktiv zu sein. In der Bachelorarbeit wird eine Studie zur Usability der Website der Landesbibliothek Oldenburg durchgeführt. Nach einer Einführung in die Thematik der Usability und der Analyse des IST-Zustandes der Website erfolgt eine Evaluation anhand von vier Methoden. Basierend auf Evaluationen mittels Personas, Heuristiken, Thinking-Aloud-Tests und einer Logfile-Analyse werden Usability-Probleme der Website ermittelt und anschließend Empfehlungen zur Verbesserung der Usability gegeben.
[Bibliotheks- und Medienpädagogik im Diskurs](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/persons/Anke+Wittich/start/2/rows/10/subjectfq/Bibliothek/docId/3148) (2024) 
[Petschenka, Anke](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Petschenka%2C+Anke) ; [Wittich, Anke](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wittich%2C+Anke)
Die Förderung von Informationskompetenz bildet traditionell einen wesentlichen Bestandteil des Veranstaltungsangebots in Bibliotheken jeglicher Ausrichtung. Seit vielen Jahren haben sich neben den Themen wie Bestandsvermittlung und Vermittlung von Recherchekenntnissen weitere Kompetenzbereiche herausgebildet, die je nach Bibliothekstyp unterschiedlich ausgeprägt sind und nach Bedarf maßgeschneidert vermittelt werden, so zum Beispiel Datenkompetenz für Studierende und Promovierende an Hochschulen oder Medienkompetenz für die Nutzenden in Öffentlichen Bibliotheken. Als theoretischer Bezugsrahmen wird vielfach auf die Bibliothekspädagogik und Medienpädagogik verwiesen, für die praktische Umsetzung werden Konzepte wie Bibliotheks-, Informations- und auch Mediendidaktik als Handlungsfelder herangezogen. In Bezug auf die Umsetzung der pädagogischen Ansätze besteht in der Berufspraxis in weiten Teilen Konsens. Die Pädagogiken unterscheiden sich durchaus in ihrer Theoriebildung, also der fachlichen Herkunft, der Ausrichtung und Schwerpunktsetzung. Der vorliegende Beitrag thematisiert die Bibliotheks- und Medienpädagogik und die ihnen zuzuordnenden Bereichs- beziehungsweise Fachdidaktiken Bibliotheks-, Informations- und Mediendidaktik. Es werden Unterschiede und Gemeinsamkeiten der hier angeführten Begriffe herausgestellt. Daraus werden Überlegungen zur Umsetzung methodischer Konzepte in der Praxis abgeleitet und Fragen zur Personalgewinnung diskutiert. Kolleginnen und Kollegen in bibliothekarischen Schulungstätigkeiten sollen unterstützt werden, ihre bislang erfolgreich durchgeführten Konzepte auch theoretisch begründet zu reflektieren und zu evaluieren.
[Fortbildung bibliothekarischer Fachkräfte an der Hochschule Hannover : Ergebnisse einer Absolventenstudie](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/persons/Anke+Wittich/start/3/rows/10/subjectfq/Bibliothek/docId/3029) (2023) 
[Bertram, Jutta](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Bertram%2C+Jutta) ; [Wittich, Anke](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wittich%2C+Anke)
Im Bachelorstudiengang Informationsmanagement – berufsbegleitend der HS Hannover werden seit zehn Jahren Fachangestellte für Medien- und Informationsdienste (FaMIs) für höhere Aufgaben im Bibliotheksbereich qualifiziert. Die Studierenden sind in öffentlichen oder wissenschaftlichen Bibliotheken tätig. Zum Studium gelangen sie entweder mit schulischer Zugangsberechtigung oder über den Weg der Offenen Hochschule Niedersachsen (FaMI-Ausbildung + mindestens dreijährige einschlägige Berufserfahrung). Anlässlich einer bevorstehenden Studienreform wurden die 125 Alumni der ersten sieben Jahrgänge im Februar 2023 in einer Onlinebefragung zu ihrem weiteren beruflichen Werdegang und ihrer retrospektiven Einschätzung des Studiums befragt (Rücklaufquote 93%). Die Ergebnisse zeigen eine sehr große Zufriedenheit mit Studium und beruflicher Entwicklung. Sie liefern zudem Anhaltspunkte für eine Ergänzung bzw. Vertiefung des Curriculums um Themen wie Personalmanagement und Open Science. Die 116 Antwortenden machten zudem deutlich, dass sie zwar als qualifizierte Fachkräfte auf dem Arbeitsmarkt willkommen sind, aber während des Studiums nicht genug Unterstützung von ihren Arbeitgebern bekommen haben. Ein Drittel von ihnen wechselte spätestens nach dem Studium die Einrichtung.
[Das Informationsverhalten von Studierenden im digitalen Zeitalter - Eine Handlungsempfehlung für Bibliotheken](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/persons/Anke+Wittich/start/4/rows/10/subjectfq/Bibliothek/docId/2212) (2022) 
[Bulmahn, Marc](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Bulmahn%2C+Marc)
Mit der zunehmenden Digitalisierung hat die Informations- und Bibliothekslandschaft einen massiven Wandel erlebt. Insbesondere die Ausbreitung des Internets hat dafür gesorgt, dass man sich bei der Informationsrecherche nicht mehr nur auf die analogen Bibliotheksbestände beschränken muss. Ziel dieser Arbeit ist es, das wissenschaftliche Informationsverhalten von Studierenden im digitalen Zeitalter zu untersuchen. Unter Anwendung eines Systematic Literature Reviews werden dabei internationale Forschungsstudien der jüngsten elf Jahren analysiert und anschließend eine Handlungsempfehlung für Bibliotheken gegeben, wie sie die Informationskompetenz der Studierenden zeitgemäß fördern können. Unter anderem ging aus den Ergebnissen hervor, dass besonders Studienanfänger*innen Defizite im Bereich der wissenschaftlichen Recherche und Quellenevaluation haben.
[Methoden und Instrumente zur Sicherung und Weitergabe von Wissen bei Personalabgängen in Bibliotheken](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/persons/Anke+Wittich/start/5/rows/10/subjectfq/Bibliothek/docId/3186) (2023) 
[Kugler, Simon](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Kugler%2C+Simon)
Bibliotheken stehen, nicht zuletzt aufgrund des aktuell stattfindenden Generationenwechsels und dem in vielen Bereichen spürbaren Fachkräftemangel, vor der Herausforderung, das Wissen ausscheidender Mitarbeiter*innen für die Einrichtung aber auch für nachfolgende Stelleninhaber*innen nachhaltig zu sichern, verfügbar zu machen und zu transferieren. Eine wachsende Zahl an Fortbildungen zeigt, dass die Themen Wissensmanagement und Wissenstransfer für Bibliotheken an Bedeutung gewonnen haben. Zum Zeitpunkt der Entstehung dieser Arbeit gab es allerdings keinen Überblick darüber, welche Maßnahmen in Bibliotheken ergriffen werden, um einem Wissensverlust im Kontext von Personalabgängen/-wechseln vorzubeugen. Ziel dieser Bachelorarbeit ist es, diese Leerstelle zumindest teilweise zu füllen, indem sie mittels einer empirischen Erhebung aufzeigt, welche Methoden und Instrumente in Bibliotheken Verwendung finden. Dem empirischen Teil vorangestellt ist eine Auseinandersetzung mit den theoretischen Grundlagen. Der Begriff Wissen wird bestimmt, ebenso der Begriff des Wissenstransfers. Relevante Wissensarten werden identifiziert und es werden, mit Blick auf das Szenario Personalabgang, ausgewählte Methoden/Instrumente angeführt. Für die Erhebung, die im zweiten Teil der Arbeit thematisiert wird, wurden leitfadengestützte Interviews geführt, die anschließend mit einer inhaltlich strukturierten qualitativen Inhaltsanalyse ausgewertet wurden. Die Fallzusammenfassungen bieten einen Blick in die einzelnen Einrichtungen. Der Vergleich der kategorisierten Aussagen gibt Aufschluss darüber, wo es Überschneidungen zwischen den Einrichtungen gibt, arbeitet aber auch Unterschiede heraus. Aus der Auswertung geht hervor, dass in den Bibliotheken verschiedene Instrumente und Maßnahmen Anwendung finden und sich die Einführung und Umsetzung von Transfermaßnahmen an den Bedarfen und Strukturen einer Einrichtung orientiert. Die Wissenssicherung erfolgt in vielen Einrichtungen über digitale Ablagesysteme und Wikis. Sitzungen und persönliche Absprachen sind allgemein für die Wissensweitergabe essentiell und bei Personalabgängen werden Transfer- und Übergabegespräche angestrebt. In einigen Einrichtungen existieren Wissenstransferprozesse. Ausgehend von den Ergebnissen stellt die Arbeit abschließend Handlungsempfehlungen für Etablierung und Umsetzung von Transfermaßnahmen zur Verfügung.
  * **1** bis **6**


