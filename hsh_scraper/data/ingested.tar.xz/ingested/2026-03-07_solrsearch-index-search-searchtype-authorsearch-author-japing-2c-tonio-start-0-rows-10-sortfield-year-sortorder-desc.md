---
source_url: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc"
title: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc"
crawl_date: "2026-03-07"
content_type: "html"
---

### Filtern
#### Autor*in 
  * [Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/author_facetfq/Adam%2C+Patricia+A.) (1)
  * [Japing, Tonio](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/author_facetfq/Japing%2C+Tonio) (1)
  * [Japing, Tonio André](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/author_facetfq/Japing%2C+Tonio+Andr%C3%A9) (1)


#### Erscheinungsjahr 
  * [2021](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/yearfq/2021) (1)
  * [2018](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/yearfq/2018) (1)


#### Dokumenttyp 
  * [Masterarbeit](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/doctypefq/masterthesis) (1)
  * [Preprint](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/doctypefq/preprint) (1)


#### Sprache 
  * [Deutsch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/languagefq/deu) (2)


#### Volltext vorhanden 
  * [ja](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/has_fulltextfq/true) (2)


#### Gehört zur Bibliographie 
  * [nein](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/belongs_to_bibliographyfq/false) (2)


#### Schlagworte 
  * [Agilität <Management>](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/subjectfq/Agilit%C3%A4t+%3CManagement%3E) (2)
  * [ISO 9001](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/subjectfq/ISO+9001) (1)
  * [Prozesse](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/subjectfq/Prozesse) (1)
  * [Prozessmanagement](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/subjectfq/Prozessmanagement) (1)
  * [Prozesssteuerung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/subjectfq/Prozesssteuerung) (1)
  * [Qualitätsmanagement](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/subjectfq/Qualit%C3%A4tsmanagement) (1)
  * [Scrum <Vorgehensmodell>](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/subjectfq/Scrum+%3CVorgehensmodell%3E) (1)
  * [Steuerung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/subjectfq/Steuerung) (1)


#### Institut 
  * [Fakultät IV - Wirtschaft und Informatik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/institutefq/Fakult%C3%A4t+IV+-+Wirtschaft+und+Informatik) (2)


###  2 Treffer
  * **1** bis **2**


Export
  * [BibTeX](https://serwiss.bib.hs-hannover.de/export/index/bibtex/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc "Export BibTeX")
  * [CSV](https://serwiss.bib.hs-hannover.de/export/index/csv/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc "Export CSV")
  * [RIS](https://serwiss.bib.hs-hannover.de/export/index/ris/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc "Export RIS")


10
  * [10](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc)
  * [20](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/20/sortfield/year/sortorder/desc)
  * [50](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/50/sortfield/year/sortorder/desc)
  * [100](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/100/sortfield/year/sortorder/desc)


Sortieren nach
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/asc)
  * Jahr 
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/title/sortorder/asc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/title/sortorder/desc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/author/sortorder/asc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/author/sortorder/desc)


[Die geplante Flexibilität : ISO 9001-konforme Steuerung agiler Prozesse](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Japing%2C+Tonio/start/0/rows/10/sortfield/year/sortorder/desc/docId/2095) (2021) 
[Japing, Tonio](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio) ; [Adam, Patricia A.](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Adam%2C+Patricia+A.)
Agile Prozesse und zertifizierte Managementsysteme wirken anfänglich wie ein Widerspruch, insbesondere hinsichtlich der Steuerung des Prozessverlaufs sowie der Kontrolle beabsichtigter Ergebnisse. Doch ein wissenschaftlicher Blick auf etablierte Formen der Prozesssteuerung legte im Rahmen einer Masterarbeit offen, dass sich einheitliche Mechanismen dahinter verbergen, die auch auf agile Prozesse angewendet werden können. Fünf erkannte Prozesssteuerungsmechanismen geben dem Leser konkrete Ansatzpunkte zur ISO 9001-konformen Steuerung und Kontrolle agiler Prozesse.
[Steuerungsmechanismen agiler Prozesse](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Japing%2C+Tonio/start/1/rows/10/sortfield/year/sortorder/desc/docId/1269) (2018) 
[Japing, Tonio André](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Japing%2C+Tonio+Andr%C3%A9)
Agilität gilt als Trend in der Unternehmensführung, kontrovers diskutiert ist jedoch die Implementierung agiler Prozesse in standardisierte Managementsysteme. Auf Grundlage einer systematischen Literaturanalyse wird sich der Synthese dieser Extreme aus empirischen Vorgehensweisen und regulierten Umgebungen gewidmet. Anhand einer eigens definierten, qualitativ angereicherten Vorgehensweise wird den Thesen gefolgt, dass agile Prozesse ähnlichen Mechanismen klassischer Prozesssteuerung unterliegen und über diese Hebel in Managementsysteme implementierbar sind. Der Annahme folgend, dass derartige Steuerungsmechanismen extrahiert und definiert werden können, wird der Transfer anhand der ISO 9000-Reihe konkretisiert. Die Ausarbeitung der Steuerungsmechanismen offenbart indessen marginale Differenzen in der Lenkung agiler und klassischer Prozesse. Im Ergebnis zeigt sich, dass ebendiese Steuerungsmechanismen ferner unter Bezugnahme auf die ISO 9001:2015 validiert werden können. Im Rahmen der Übertragung auf agile Prozesse überwiegt die Kompatibilität, jedoch schmälert die inhärente Informalität agiler Prozesse unter Umständen die Wahrscheinlichkeit einer Zertifizierung und bedarf daher gesonderter Betrachtung.
  * **1** bis **2**


