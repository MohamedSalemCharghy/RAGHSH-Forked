---
source_url: "https://mediathek.f3.hs-hannover.de/mediathek/video/bvm_image_2022-mp4"
title: "BVM_Image_2022.mp4"
crawl_date: "2026-03-07"
content_type: "html"
---

Video-Player wird geladen.
Video abspielen
Wiedergabe
Ton aus
Aktueller Zeitpunkt 0:00
/
Dauer 0:00
Geladen: 0%
0:00
Streamtyp LIVE
Zur Live-Übertragung wechseln. Aktuell wird es nicht live abgespielt.LIVE
Verbleibende Zeit -0:00
1x
Wiedergabegeschwindigkeit
Kapitel
  * Kapitel


Beschreibungen
  * Beschreibungen aus, ausgewählt


Untertitel
  * Untertiteleinstellungen, öffnet Einstellungen für Untertitel
  * Untertitel aus, ausgewählt


Tonspur
Bild-im-Bild-ModusVollbild
This is a modal window.
Anfang des Dialogfensters. Esc bricht ab und schließt das Fenster.
Schrift ColorWeiß Schwarz Rot Grün Blau Gelb Magenta TürkisTransparencyUndurchsichtig Halbdurchsichtig Hintergrund ColorSchwarz Weiß Rot Grün Blau Gelb Magenta TürkisTransparencyUndurchsichtig Halbdurchsichtig Durchsichtig Fenster ColorSchwarz Weiß Rot Grün Blau Gelb Magenta TürkisTransparencyDurchsichtig Halbdurchsichtig Undurchsichtig
Schriftgröße 50% 75% 100% 125% 150% 175% 200% 300% 400% Textkantenstil Kein Erhoben Gedrückt Uniform Schlagschatten Schriftfamilie Proportionale Sans-Serif Monospace Sans-Serif Proportionale Serif Monospace Serif Zwanglos Schreibschrift Small-Caps
Zurücksetzen Alle Einstellungen auf die Standardwerte zurücksetzenFertig
Modales Fenster schließen
Ende des Dialogfensters.
20. April 2023 , 13:48 Uhr/play_circle_outline01:52
# BVM_Image_2022.mp4
Eine Reise durch den Bachelorstudiengang Veranstaltungsmanagement
Kommunikation, Projektplanung, kreative Gestaltung – das sind nur drei der Kompetenzfelder, die die BVM-Studierenden im 4. Semester für die Produktion des Messe-Imagevideos unseres Studiengangs genutzt haben. Was man auf der Reise durch sieben Semester BVM noch alles mitnimmt, zeigen sie euch hier.
[Facebook](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fmediathek.f3.hs-hannover.de%2Fmediathek%2Fvideo%2Fbvm_image_2022-mp4%2F& "Auf Facebook teilen")[X.com](https://twitter.com/intent/tweet?url=https%3A%2F%2Fmediathek.f3.hs-hannover.de%2Fshare%2F9366&text=BVM_Image_2022.mp4 "Auf X teilen") [WhatsApp](whatsapp://send?text=https%3A%2F%2Fmediathek.f3.hs-hannover.de%2Fshare%2F9366%20-%20BVM_Image_2022.mp4 "Über WhatsApp teilen")E-Mail senden
