---
source_url: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica"
title: "https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica"
crawl_date: "2026-03-07"
content_type: "html"
---

### Filtern
#### Autor*in 
  * [Bartels, Thomas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Bartels%2C+Thomas) (3)
  * [Homeyer, Kai](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Homeyer%2C+Kai) (3)
  * [Raabe, Jessica](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Raabe%2C+Jessica) (3)
  * [Raveendran, Gurubaran](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Raveendran%2C+Gurubaran) (3)
  * [Lachmayer, Roland](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Lachmayer%2C+Roland) (2)
  * [Beyki, Mohammed](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Beyki%2C+Mohammed) (1)
  * [Flemming, Jesko](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Flemming%2C+Jesko) (1)
  * [Grotjahn, Martin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Grotjahn%2C+Martin) (1)
  * [Grude, Leon](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/Grude%2C+Leon) (1)
  * [Heüveldop, Dörte](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/author_facetfq/He%C3%BCveldop%2C+D%C3%B6rte) (1)


[ + weitere](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/facetNumber_author_facet/all#author_facet_facet "alle Ergebnisse anzeigen")
#### Erscheinungsjahr 
  * [2024](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/yearfq/2024) (1)
  * [2023](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/yearfq/2023) (2)


#### Dokumenttyp 
  * [Aufsatz, Zeitschriftenartikel](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/doctypefq/article) (1)
  * [Buch (Monographie)](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/doctypefq/book) (1)
  * [Konferenzveröffentlichung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/doctypefq/conferenceobject) (1)


#### Sprache 
  * [Deutsch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/languagefq/deu) (1)
  * [Englisch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/languagefq/eng) (1)
  * [Mehrsprachig](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/languagefq/mul) (1)


#### Volltext vorhanden 
  * [ja](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/has_fulltextfq/true) (3)


#### Gehört zur Bibliographie 
  * [nein](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/belongs_to_bibliographyfq/false) (3)


#### Schlagworte 
  * [Lichttechnik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Lichttechnik) (2)
  * [24/7 Tierverfolgung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/24%2F7+Tierverfolgung) (1)
  * [Automation](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Automation) (1)
  * [Automation technology](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Automation+technology) (1)
  * [Beleuchtung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Beleuchtung) (1)
  * [Corticosteron](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Corticosteron) (1)
  * [Datenaustausch](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Datenaustausch) (1)
  * [Digitalisierung in der Putenhaltung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Digitalisierung+in+der+Putenhaltung) (1)
  * [Flimmerbewegung](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Flimmerbewegung) (1)
  * [Geflügel](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/subjectfq/Gefl%C3%BCgel) (1)


[ + weitere](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/facetNumber_subject/all#subject_facet "alle Ergebnisse anzeigen")
#### Institut 
  * [Fakultät I - Elektro- und Informationstechnik](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/institutefq/Fakult%C3%A4t+I+-+Elektro-+und+Informationstechnik) (3)
  * [ISA - Institut für Sensorik und Automation](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/institutefq/ISA+-+Institut+f%C3%BCr+Sensorik+und+Automation) (1)


###  3 Treffer
  * **1** bis **3**


Export
  * [BibTeX](https://serwiss.bib.hs-hannover.de/export/index/bibtex/searchtype/authorsearch/author/Raabe%2C+Jessica "Export BibTeX")
  * [CSV](https://serwiss.bib.hs-hannover.de/export/index/csv/searchtype/authorsearch/author/Raabe%2C+Jessica "Export CSV")
  * [RIS](https://serwiss.bib.hs-hannover.de/export/index/ris/searchtype/authorsearch/author/Raabe%2C+Jessica "Export RIS")


10
  * [10](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/rows/10)
  * [20](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/rows/20)
  * [50](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/rows/50)
  * [100](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/rows/100)


Sortieren nach
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/sortfield/year/sortorder/asc)
  * [ Jahr ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/sortfield/year/sortorder/desc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/sortfield/title/sortorder/asc)
  * [ Titel ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/sortfield/title/sortorder/desc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/sortfield/author/sortorder/asc)
  * [ Autor*in ](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica/start/0/rows/10/sortfield/author/sortorder/desc)


[Research Note: Irritating flashing light or poultry-friendly lighting—are flicker frequencies of LED luminaires a potential stress factor in the husbandry of male fattening turkeys?](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Raabe%2C+Jessica/docId/3015/start/0/rows/10) (2023) 
[Raabe, Jessica](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica) ; [Raveendran, Gurubaran](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raveendran%2C+Gurubaran) ; [Otten, Winfried](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Otten%2C+Winfried) ; [Homeyer, Kai](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Homeyer%2C+Kai) ; [Bartels, Thomas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Bartels%2C+Thomas)
Conventional fluorescent tubes are increasingly being replaced with innovative light-emitting diodes (LEDs) for lighting poultry houses. However, little is known about whether the flicker frequencies of LED luminaires are potential stressors in poultry husbandry. The term “light flicker” describes the fluctuations in the brightness of an electrically operated light source caused by the design and/or control of the light source. In this context, the critical flicker frequency (CFF) characterizes the frequency at which a sequence of light flashes is perceived as continuous light. It is known that CFF in birds is higher than that in humans and that light flicker can affect behavioral patterns and stress levels in several bird species. As there is a lack of knowledge about the impact of flicker frequency on fattening turkeys, this study aimed to investigate the effects of flicker frequency on the behavior, performance, and stress response in male turkeys. In 3 trials, a total of 1,646 male day-old turkey poults of the strain B.U.T. 6 with intact beaks were reared for 20 wk in 12 barn compartments of 18 m² each. Each barn compartment was illuminated using 2 full-spectrum LED lamps. Flicker frequencies of 165 Hz, 500 Hz, and 16 kHz were set in the luminaires to illuminate the compartments. Analyses of feather corticosterone concentration were performed on fully grown third-generation primaries (P 3) of 5 turkeys from each compartment. No significant differences were found in the development of live weight, feed consumption, or prevalence of injured or killed turkeys by conspecifics reared under the above flicker frequencies. The flicker frequencies also did not significantly influence feather corticosterone concentrations in the primaries of the turkeys. In conclusion, the present results indicate that flicker frequencies of 165 Hz or higher have no detrimental effect on growth performance, injurious pecking, or endocrine stress response in male turkeys and, thus, may be suitable for use as animal-friendly lighting.
[Beleuchtung als Einflussfaktor für eine tiergerechte Mastputenhaltung](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Raabe%2C+Jessica/docId/3557/start/1/rows/10) (2023) 
[Raveendran, Gurubaran](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raveendran%2C+Gurubaran) ; [Homeyer, Kai](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Homeyer%2C+Kai) ; [Raabe, Jessica](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica) ; [Bartels, Thomas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Bartels%2C+Thomas) ; [Lachmayer, Roland](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Lachmayer%2C+Roland)
Im Rahmen des Forschungsprojekts „Optimierung des Lichtmanagements in der Haltung von Mastputen“ (OptiLiMa) wird der Einfluss der Stallbeleuchtung auf das Verhalten von Mastputen untersucht. Dafür wird eine LED-Vollspektrumbeleuchtung mit Wellenlängen vom UVA-Bereich bis zum sichtbaren Licht sowie ein automatisches Tierbeobachtungssystem mittels KI-videobasierter Objekterkennung entwickelt. Im Fokus der Untersuchungen steht dabei ein bislang wenig untersuchter möglicher Haltungsfaktor, der Einfluss der Beleuchtung auf das Verhalten von Mastputen. Getestet wurde einerseits die Auswirkung von Flimmerfrequenzen mit 165 Hz, 500 Hz und 16 kHz sowie andererseits unterschiedliche Lichtspektren im für Menschen sichtbaren Bereich mit und ohne einen zusätzlichen UVA-Anteil. Die von den Puten bevorzugten Aufenthaltsbereiche im Maststall wurden analysiert. Zusätzlich wurde in Federproben die Konzentration von Corticosteron gemessen, um die Effekte der verschiedenen Flimmerfrequenzen auf die Langzeitsekretion dieses Stresshormons als Reaktion auf die Umgebungsbedingungen zu erfassen. Ziel der Studie ist es, Parameter für eine den Haltungsansprüchen von Mastputen gerecht werdende Stallbeleuchtung zu bestimmen, die ggf. zur Verbesserung des Tierwohls beitragen kann.
[Sensorik und Automation: Schriften des Forschungsinstituts ISA 2024](https://serwiss.bib.hs-hannover.de/frontdoor/index/index/searchtype/authorsearch/author/Raabe%2C+Jessica/docId/3245/start/2/rows/10) (2024) 
[Bartels, Thomas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Bartels%2C+Thomas) ; [Beyki, Mohammed](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Beyki%2C+Mohammed) ; [Flemming, Jesko](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Flemming%2C+Jesko) ; [Grude, Leon](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Grude%2C+Leon) ; [Homann, Hanno](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Homann%2C+Hanno) ; [Homeyer, Kai](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Homeyer%2C+Kai) ; [Jakoblew, Sascha](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Jakoblew%2C+Sascha) ; [Kallisch, Jonas](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Kallisch%2C+Jonas) ; [Kizilarslan, Metin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Kizilarslan%2C+Metin) ; [Knop, Werner](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Knop%2C+Werner) ; [Lachmayer, Roland](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Lachmayer%2C+Roland) ; [Niemann, Karl-Heinz](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Niemann%2C+Karl-Heinz) ; [Passoke, Jens](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Passoke%2C+Jens) ; [Patzke, Robert](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Patzke%2C+Robert) ; [Pawlak, Justus](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Pawlak%2C+Justus) ; [Raabe, Jessica](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raabe%2C+Jessica) ; [Raveendran, Gurubaran](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Raveendran%2C+Gurubaran) ; [Renz, Franz](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Renz%2C+Franz) ; [Schomburg, Helen](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Schomburg%2C+Helen) ; [Sahan, Benjamin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Sahan%2C+Benjamin) ; [Streitenberger, Martin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Streitenberger%2C+Martin) ; [Tegeler, Sebastian](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Tegeler%2C+Sebastian) ; [Will, Jens Christian](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Will%2C+Jens+Christian) ; [Winnefeld, Jannis](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Winnefeld%2C+Jannis) ; [Witte, Pascal](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Witte%2C+Pascal) ; [Wittig, Christoph](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wittig%2C+Christoph) ; [Wicht, Bernhard](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wicht%2C+Bernhard) ; [Wulfmeier, Kirsten](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wulfmeier%2C+Kirsten) ; [Wunck, Christoph](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Wunck%2C+Christoph) ; [Heüveldop, Dörte](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/He%C3%BCveldop%2C+D%C3%B6rte) ; [Grotjahn, Martin](https://serwiss.bib.hs-hannover.de/solrsearch/index/search/searchtype/authorsearch/author/Grotjahn%2C+Martin)
Das Institut für Sensorik und Automation (ISA) stellt in acht Beiträgen aktuelle Ergebnisse aus seinen vielfältigen Forschungsprojekten vor. Es werden Themen angesprochen wie Lichttechnik in der Nutzgeflügelhaltung, Datenaustausch in der Produktion, hochfrequente Front-Ends für Umweltsensoren in der Gebäudeautomatisierung, Mössbauer-Spektroskopie, Entwicklung fortschrittlicher Transimpedanzverstärker, Optimierung monostatischer Transceiver, Datenverarbeitungsszenarien für Smart-Home-Systeme und Designüberlegungen für kryogene Analog-Digital-Wandler.
  * **1** bis **3**


